package com.cgv.mvc;

public class TicketVO {

}
